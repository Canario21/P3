package control;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;

public class ManejadorBaseDeDatos {
    Connection conexion;
    Statement st;
    ResultSet resultado;

    public ManejadorBaseDeDatos() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/bd_peliculas?useSSL=false";
            Connection conexion = java.sql.DriverManager.getConnection(url, "root", "");
            st = conexion.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {
        }
    }

    public ArrayList<String> obtenerPeliculas() {
        ArrayList<String> lista = new ArrayList();
        try {
            resultado = st.executeQuery("SELECT id_pelicula, titulo FROM peliculas");
            while (resultado.next()) {
                lista.add(resultado.getString("titulo"));
            }
            return lista;
        } catch (SQLException ex) {
        }
        return null;
    }

    public String[] obtenerDatosDePelicula(String nombre) {
        try {
            String[] datos = new String[4];
            resultado = st.executeQuery(
            "SELECT * FROM cines, peliculas WHERE cines.id_cine = peliculas.id_cine AND peliculas.titulo ='"+nombre+"'");
            resultado.next();
            datos[0] = resultado.getString("nombre");
            datos[1] = resultado.getString("ubicacion");
            datos[2] = resultado.getString("titulo");
            datos[3] = resultado.getString("genero");
        return datos;
        } catch (SQLException ex) {
               }
        return null;
    }

    public void cerrar() {
        try {
            if (resultado != null) {
                resultado.close();
            }
            st.close();
            conexion.close();
        } catch (SQLException ex) {
        }
    }
}
