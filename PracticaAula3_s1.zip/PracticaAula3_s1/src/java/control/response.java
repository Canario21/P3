package control;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class response extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
        
            // Recuperar datos del formulario
            String  pelicula = request.getParameter("id_pelicula");
            // Habilitar conexion con BBDD
            ManejadorBaseDeDatos bd = new ManejadorBaseDeDatos();
            // Realizar la operacion con la BBDD
            String[] lista = bd.obtenerDatosDePelicula(pelicula);
            // cerrra conexion con la BBDD 
            //bd.cerrar();
            // actualizar las etquetas "pendiente" del codigo inferior
            String pendiente = "actualizar";
            out.println("<HTML>");
            out.println("<HEAD> <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
            out.println(" <TITLE> Cartelera cinematografica </TITLE>");
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"estilo.css\"> </HEAD>");
            out.println("<BODY>");
            out.println("<table border=\"0\">");
            out.println("<tr>");
            out.println("<td><big><strong>Nombre de la pelicula:</strong></big></td>");
            out.println("<td><span style=\"font-size:large; font-style:italic;\">" + lista[0] + "</span></td>");
            out.println("</tr> ");
            out.println("<tr>");
            out.println("<td><strong>Genero:</strong></td>");
            out.println("<td><span style=\"font-size:large; font-style: italic;\">" +lista[1] + "</span></td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td><strong>Cine:</strong></td>");
            out.println("<td><strong>" + lista[2] + "</strong>");
            out.println("</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td><strong>Localizacion:</strong></td>");
            out.println("<td>" + lista[3] + "</td>");
            out.println("</tr>");
            out.println("</table>");
            out.println("</BODY>");
            out.println("</HTML>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}
